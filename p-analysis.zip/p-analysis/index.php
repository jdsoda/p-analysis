<?php
// ─────────────────────────────────────────────
//  CONFIG – Change password here
// ─────────────────────────────────────────────
define('APP_PASSWORD', 'CA@2024');   // ← apni password ikkade set cheyandi
define('SESSION_TIMEOUT', 3600);     // 1 hour auto-logout

session_start();

// ── Logout ──
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit;
}

// ── Login submit ──
if (isset($_POST['login'])) {
    if ($_POST['password'] === APP_PASSWORD) {
        $_SESSION['auth']     = true;
        $_SESSION['login_at'] = time();
    } else {
        $login_error = "Incorrect password. Please try again.";
    }
}

// ── Session timeout check ──
if (isset($_SESSION['auth'])) {
    if (time() - $_SESSION['login_at'] > SESSION_TIMEOUT) {
        session_destroy();
        header('Location: index.php?timeout=1');
        exit;
    }
}

$authenticated = !empty($_SESSION['auth']);

// ─────────────────────────────────────────────
//  EXCEL DOWNLOAD (before any HTML output)
// ─────────────────────────────────────────────
if ($authenticated && isset($_GET['download_excel']) && isset($_SESSION['result_json_path'])) {
    $json_path = $_SESSION['result_json_path'];
    $pdf_name  = $_SESSION['pdf_name'] ?? 'Statement';

    if (file_exists($json_path)) {
        $xlsx_path = sys_get_temp_dir() . '/panalysis_export_' . time() . '.xlsx';
        $cmd = "python3 export.py \"$json_path\" \"$xlsx_path\" \"$pdf_name\" 2>&1";
        $out = shell_exec($cmd);
        if (!$out || strpos($out, 'OK:') === false) {
            $cmd = "python export.py \"$json_path\" \"$xlsx_path\" \"$pdf_name\" 2>&1";
            $out = shell_exec($cmd);
        }

        if (file_exists($xlsx_path)) {
            $filename = 'P-Analysis_' . preg_replace('/[^a-zA-Z0-9_]/', '_', $pdf_name) . '_' . date('d-M-Y') . '.xlsx';
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Content-Length: ' . filesize($xlsx_path));
            header('Cache-Control: no-cache');
            readfile($xlsx_path);
            unlink($xlsx_path);
            exit;
        } else {
            if (strpos($out, 'openpyxl') !== false) {
                $excel_error = "openpyxl library install cheyandi. XAMPP Shell lo run cheyandi: <code>pip install openpyxl</code>";
            } else {
                $excel_error = "Excel generation failed: " . htmlspecialchars($out);
            }
        }
    }
}

// ─────────────────────────────────────────────
//  PDF ANALYSIS
// ─────────────────────────────────────────────
$results   = [];
$error_msg = $excel_error ?? "";
$summary   = [];

if ($authenticated && isset($_POST['submit'])) {
    if (!is_dir('uploads')) { mkdir('uploads', 0777, true); }

    $pdf_name = $_FILES["pdf_file"]["name"];
    $target   = "uploads/" . basename($pdf_name);

    if (move_uploaded_file($_FILES["pdf_file"]["tmp_name"], $target)) {
        $command = "python3 analyze.py \"$target\" 2>&1";
        $output  = shell_exec($command);
        if (!$output) {
            $command = "python analyze.py \"$target\" 2>&1";
            $output  = shell_exec($command);
        }

        $results = json_decode($output, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            $error_msg = "Script Error: " . htmlspecialchars($output);
        } else {
            $json_path = sys_get_temp_dir() . '/panalysis_' . session_id() . '.json';
            file_put_contents($json_path, $output);
            $_SESSION['result_json_path'] = $json_path;
            $_SESSION['pdf_name']         = pathinfo($pdf_name, PATHINFO_FILENAME);

            $summary['total_parties'] = count($results);
            $summary['total_debit']   = array_sum(array_map(fn($r)=>floatval($r['total_debit'] ?? $r['Debit'] ?? 0), $results));
            $summary['total_credit']  = array_sum(array_map(fn($r)=>floatval($r['total_credit'] ?? $r['Credit'] ?? 0), $results));
            $summary['flagged_count'] = count(array_filter($results, fn($r) => !empty($r['flags'])));
            $summary['total_txns']    = array_sum(array_map(fn($r)=>intval($r['count'] ?? $r['Count'] ?? 0), $results));
        }
    } else {
        $error_msg = "File upload failed. Check server permissions.";
    }
}

// Re-load previous session results
if ($authenticated && empty($results) && isset($_SESSION['result_json_path'])
    && file_exists($_SESSION['result_json_path']) && !isset($_POST['submit'])) {
    $prev = json_decode(file_get_contents($_SESSION['result_json_path']), true);
    if ($prev && json_last_error() === JSON_ERROR_NONE) {
        $results = $prev;
        $summary['total_parties'] = count($results);
        $summary['total_debit']   = array_sum(array_map(fn($r)=>floatval($r['total_debit'] ?? $r['Debit'] ?? 0), $results));
        $summary['total_credit']  = array_sum(array_map(fn($r)=>floatval($r['total_credit'] ?? $r['Credit'] ?? 0), $results));
        $summary['flagged_count'] = count(array_filter($results, fn($r) => !empty($r['flags'])));
        $summary['total_txns']    = array_sum(array_map(fn($r)=>intval($r['count'] ?? $r['Count'] ?? 0), $results));
    }
}

function flag_class($flags) {
    if (empty($flags)) return '';
    foreach ($flags as $f) {
        if (strpos($f,'RETURNED')!==false || strpos($f,'REVERSED')!==false) return 'row-danger';
        if (strpos($f,'HIGH VALUE')!==false || strpos($f,'10L')!==false)    return 'row-warning';
    }
    return 'row-info';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>P-ANALYSIS | Bank Audit Tool</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg:#0d1117; --surface:#161b22; --surface2:#1c2128; --border:#30363d;
            --text:#e6edf3; --muted:#8b949e; --gold:#d4a72c; --gold-dim:#6e5218;
            --danger:#f85149; --danger-bg:#3d1214; --warn:#e3b341; --warn-bg:#3a2200;
            --info:#58a6ff; --info-bg:#0d2a4a; --green:#3fb950;
        }
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
        body{font-family:'IBM Plex Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;}

        /* TOP BAR */
        .topbar{background:var(--surface);border-bottom:1px solid var(--border);padding:12px 32px;display:flex;align-items:center;gap:16px;}
        .logo{font-family:'IBM Plex Mono',monospace;font-size:1.1rem;font-weight:600;color:var(--gold);letter-spacing:2px;}
        .subtitle{font-size:.75rem;color:var(--muted);letter-spacing:1px;text-transform:uppercase;}
        .badge-it{background:var(--gold-dim);color:var(--gold);font-size:.65rem;font-weight:700;padding:4px 10px;border-radius:20px;letter-spacing:1px;text-transform:uppercase;}
        .topbar-r{margin-left:auto;display:flex;align-items:center;gap:10px;}
        .btn-logout{background:transparent;border:1px solid var(--border);color:var(--muted);padding:5px 14px;border-radius:5px;font-size:.75rem;cursor:pointer;font-family:inherit;transition:.2s;}
        .btn-logout:hover{border-color:var(--danger);color:var(--danger);}

        /* LOGIN */
        .login-wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;}
        .login-card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:48px 44px;width:100%;max-width:420px;text-align:center;}
        .lock{font-size:2.5rem;margin-bottom:16px;}
        .login-card h1{font-family:'IBM Plex Mono',monospace;font-size:1.3rem;color:var(--gold);letter-spacing:2px;margin-bottom:6px;}
        .tagline{font-size:.78rem;color:var(--muted);margin-bottom:32px;}
        .login-card label{display:block;text-align:left;font-size:.72rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;}
        .login-card input[type="password"]{width:100%;background:var(--surface2);border:1px solid var(--border);color:var(--text);padding:12px 16px;border-radius:7px;font-family:'IBM Plex Mono',monospace;font-size:.95rem;transition:.2s;margin-bottom:18px;}
        .login-card input[type="password"]:focus{outline:none;border-color:var(--gold);}
        .btn-login{width:100%;background:var(--gold);color:#000;border:none;padding:13px;border-radius:7px;font-weight:700;font-size:.95rem;cursor:pointer;transition:.2s;}
        .btn-login:hover{opacity:.85;}
        .login-error{background:var(--danger-bg);border:1px solid var(--danger);color:var(--danger);border-radius:6px;padding:10px 14px;font-size:.8rem;margin-bottom:18px;text-align:left;}
        .login-timeout{background:var(--warn-bg);border:1px solid var(--warn);color:var(--warn);border-radius:6px;padding:10px 14px;font-size:.8rem;margin-bottom:18px;text-align:left;}
        .login-footer{margin-top:28px;font-size:.68rem;color:var(--muted);}

        /* MAIN */
        .main{max-width:1300px;margin:0 auto;padding:32px 24px;}
        .upload-card{background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:28px;margin-bottom:28px;}
        .upload-card h2{font-size:.8rem;color:var(--muted);letter-spacing:2px;text-transform:uppercase;margin-bottom:18px;}
        .upload-row{display:flex;gap:12px;align-items:center;flex-wrap:wrap;}
        .file-wrap{flex:1;min-width:260px;}
        .file-wrap input[type="file"]{width:100%;background:var(--surface2);border:1px dashed var(--border);border-radius:6px;padding:10px 14px;color:var(--text);font-family:'IBM Plex Mono',monospace;font-size:.85rem;cursor:pointer;transition:.2s;}
        .file-wrap input[type="file"]:hover{border-color:var(--gold);}
        .file-wrap input[type="file"]::file-selector-button{background:var(--gold-dim);color:var(--gold);border:none;padding:6px 14px;border-radius:4px;font-family:'IBM Plex Mono',monospace;font-size:.8rem;cursor:pointer;margin-right:12px;}
        .btn-analyze{background:var(--gold);color:#000;border:none;padding:11px 28px;border-radius:6px;font-weight:700;font-size:.9rem;cursor:pointer;white-space:nowrap;transition:.2s;}
        .btn-analyze:hover{opacity:.85;}
        .note{margin-top:12px;font-size:.75rem;color:var(--muted);}

        /* EXCEL BUTTON */
        .btn-excel{display:inline-flex;align-items:center;gap:8px;background:#1D6F42;color:#fff;border:none;padding:10px 22px;border-radius:6px;font-weight:700;font-size:.85rem;cursor:pointer;text-decoration:none;letter-spacing:.3px;transition:.2s;margin-bottom:22px;}
        .btn-excel:hover{background:#155734;}

        /* ALERT */
        .alert-err{background:var(--danger-bg);border:1px solid var(--danger);color:var(--danger);border-radius:8px;padding:14px 18px;margin-bottom:24px;font-family:'IBM Plex Mono',monospace;font-size:.8rem;}

        /* SUMMARY */
        .summary-strip{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:14px;margin-bottom:28px;}
        .stat-box{background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:16px 20px;}
        .stat-box .label{font-size:.7rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;}
        .stat-box .value{font-family:'IBM Plex Mono',monospace;font-size:1.25rem;font-weight:600;color:var(--text);}
        .stat-box.flagged .value{color:var(--danger);}
        .stat-box.debit .value{color:#f85149;}
        .stat-box.credit .value{color:var(--green);}

        /* TABLE */
        .section-header{display:flex;align-items:center;gap:12px;margin-bottom:14px;flex-wrap:wrap;}
        .section-header h3{font-size:.75rem;color:var(--muted);text-transform:uppercase;letter-spacing:2px;}
        .count-badge{background:var(--surface2);border:1px solid var(--border);color:var(--muted);font-family:'IBM Plex Mono',monospace;font-size:.7rem;padding:2px 8px;border-radius:20px;}
        .search-bar{margin-left:auto;}
        .search-bar input{background:var(--surface2);border:1px solid var(--border);color:var(--text);padding:7px 14px;border-radius:6px;font-family:'IBM Plex Mono',monospace;font-size:.8rem;width:220px;}
        .search-bar input:focus{outline:none;border-color:var(--gold);}

        .table-wrap{background:var(--surface);border:1px solid var(--border);border-radius:10px;overflow:hidden;overflow-x:auto;}
        .audit-table{width:100%;border-collapse:collapse;font-size:.83rem;min-width:800px;}
        .audit-table thead th{background:var(--surface2);color:var(--muted);font-size:.68rem;text-transform:uppercase;letter-spacing:1px;padding:12px 14px;text-align:left;border-bottom:1px solid var(--border);white-space:nowrap;}
        .audit-table thead th.num{text-align:right;}
        .audit-table tbody tr{border-bottom:1px solid var(--border);transition:background .15s;}
        .audit-table tbody tr:last-child{border-bottom:none;}
        .audit-table tbody tr:hover{background:rgba(255,255,255,.03);}
        .audit-table td{padding:10px 14px;vertical-align:middle;}
        .audit-table td.num{text-align:right;font-family:'IBM Plex Mono',monospace;font-size:.8rem;}
        .audit-table td.pname{font-weight:600;max-width:240px;word-break:break-word;}
        .row-danger{background:rgba(248,81,73,.07)!important;}
        .row-warning{background:rgba(227,179,65,.06)!important;}
        .row-info{background:rgba(88,166,255,.05)!important;}

        .flags-cell{max-width:260px;}
        .fp{display:inline-block;font-size:.6rem;font-weight:700;padding:2px 7px;border-radius:20px;margin:2px 2px 2px 0;text-transform:uppercase;}
        .fp-d{background:var(--danger-bg);color:var(--danger);border:1px solid var(--danger);}
        .fp-w{background:var(--warn-bg);color:var(--warn);border:1px solid var(--warn);}
        .fp-i{background:var(--info-bg);color:var(--info);border:1px solid var(--info);}
        .fp-ok{color:var(--green);font-size:.75rem;}

        .dr{color:#f85149;} .cr{color:var(--green);}
        .npos{color:var(--green);} .nneg{color:#f85149;} .nzero{color:var(--muted);}
        .sr{color:var(--muted);font-family:'IBM Plex Mono',monospace;font-size:.75rem;}

        footer{text-align:center;color:var(--muted);font-size:.72rem;padding:24px;border-top:1px solid var(--border);margin-top:48px;}
        @media(max-width:768px){.main{padding:16px 12px;}.audit-table td{padding:8px 10px;}}
    </style>
</head>
<body>

<?php if (!$authenticated): ?>
<!-- ══════════════ LOGIN ══════════════ -->
<div class="login-wrap">
  <div class="login-card">
    <div class="lock">🔐</div>
    <h1>P-ANALYSIS</h1>
    <p class="tagline">Bank Statement Audit Tool &nbsp;·&nbsp; CA Access Only</p>

    <?php if (!empty($login_error)): ?>
      <div class="login-error">⚠ <?= htmlspecialchars($login_error) ?></div>
    <?php endif; ?>
    <?php if (isset($_GET['timeout'])): ?>
      <div class="login-timeout">⏱ Session expired. Please login again.</div>
    <?php endif; ?>

    <form method="post">
      <label for="pwd">Password</label>
      <input type="password" id="pwd" name="password" placeholder="Enter password" autofocus required>
      <button type="submit" name="login" class="btn-login">🔓 Login</button>
    </form>
    <div class="login-footer">Designed for CA / IT Audit use · Sec 44AB / 269SS / SFT</div>
  </div>
</div>

<?php else: ?>
<!-- ══════════════ APP ══════════════ -->
<header class="topbar">
  <div>
    <div class="logo">⬡ P-ANALYSIS</div>
    <div class="subtitle">Bank Statement Audit Tool</div>
  </div>
  <div class="topbar-r">
    <span class="badge-it">IT / GST Audit Ready</span>
    <form method="get" style="margin:0;">
      <button type="submit" name="logout" class="btn-logout">⏻ Logout</button>
    </form>
  </div>
</header>

<div class="main">
  <!-- Upload -->
  <div class="upload-card">
    <h2>Upload Bank Statement (PDF)</h2>
    <form method="post" enctype="multipart/form-data">
      <div class="upload-row">
        <div class="file-wrap">
          <input type="file" name="pdf_file" accept=".pdf" required>
        </div>
        <button type="submit" name="submit" class="btn-analyze">▶ Analyze</button>
      </div>
    </form>
    <p class="note">ⓘ Supports SBI, HDFC, ICICI, Axis, Canara &amp; most PDFs &nbsp;|&nbsp; Party-wise aggregation &nbsp;|&nbsp; Auto IT/GST flags</p>
  </div>

  <?php if ($error_msg): ?>
    <div class="alert-err">⚠ <?= $error_msg ?></div>
  <?php endif; ?>

  <?php if (!empty($results)): ?>

    <!-- Excel Download -->
    <a href="index.php?download_excel=1" class="btn-excel">📥 &nbsp;Download Excel Report</a>

    <!-- Stats -->
    <div class="summary-strip">
      <div class="stat-box"><div class="label">Total Parties</div><div class="value"><?= number_format($summary['total_parties']) ?></div></div>
      <div class="stat-box"><div class="label">Total Transactions</div><div class="value"><?= number_format($summary['total_txns']) ?></div></div>
      <div class="stat-box debit"><div class="label">Total Debit (₹)</div><div class="value"><?= number_format($summary['total_debit']/100000,2) ?>L</div></div>
      <div class="stat-box credit"><div class="label">Total Credit (₹)</div><div class="value"><?= number_format($summary['total_credit']/100000,2) ?>L</div></div>
      <div class="stat-box flagged"><div class="label">🚩 Flagged Parties</div><div class="value"><?= $summary['flagged_count'] ?></div></div>
    </div>

    <!-- Table -->
    <div class="section-header">
      <h3>Party-wise Payment Summary</h3>
      <span class="count-badge"><?= count($results) ?> parties</span>
      <div class="search-bar"><input type="text" id="partySearch" placeholder="🔍 Search party..." onkeyup="filterTable()"></div>
    </div>

    <div class="table-wrap">
      <table class="audit-table" id="auditTable">
        <thead>
          <tr>
            <th style="width:36px">#</th>
            <th>Party Name</th>
            <th class="num">Entries</th>
            <th class="num">Total Debit (₹)</th>
            <th class="num">Total Credit (₹)</th>
            <th class="num">Net (₹)</th>
            <th class="num">Max Single (₹)</th>
            <th>Audit Flags</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($results as $i => $row):
            $rc  = flag_class($row['flags'] ?? []);
            $net = floatval($row['net'] ?? ($row['Net'] ?? 0));
            $nc  = ($net>0.01)?'npos':(($net<-0.01)?'nneg':'nzero');
            $td  = floatval($row['total_debit']  ?? ($row['Debit']  ?? 0));
            $tc  = floatval($row['total_credit'] ?? ($row['Credit'] ?? 0));
            $cnt = intval($row['count']      ?? ($row['Count'] ?? 0));
            $mx  = floatval($row['max_single']   ?? 0);
            $pty = $row['party'] ?? ($row['Ref'] ?? 'Unknown');
          ?>
          <tr class="<?=$rc?>">
            <td class="sr"><?=$i+1?></td>
            <td class="pname"><?=htmlspecialchars($pty)?></td>
            <td class="num"><?=$cnt?></td>
            <td class="num dr"><?=$td>0?number_format($td,2):'—'?></td>
            <td class="num cr"><?=$tc>0?number_format($tc,2):'—'?></td>
            <td class="num <?=$nc?>"><?=number_format($net,2)?></td>
            <td class="num"><?=$mx>0?number_format($mx,2):'—'?></td>
            <td class="flags-cell">
              <?php if(empty($row['flags'])): ?>
                <span class="fp-ok">✓ Normal</span>
              <?php else: foreach($row['flags'] as $f):
                $fw=strtoupper(explode(' ',$f)[0]);
                $fc=in_array($fw,['CHEQUE','RETURNED','REVERSED'])?'fp-d':(in_array($fw,['HIGH','AGGREGATE'])?'fp-w':'fp-i');
              ?>
                <span class="fp <?=$fc?>"><?=htmlspecialchars($f)?></span>
              <?php endforeach;endif;?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div style="margin-top:16px;font-size:.72rem;color:var(--muted);display:flex;gap:18px;flex-wrap:wrap;">
      <span style="color:var(--danger)">■ Cheque Returned/Reversed</span>
      <span style="color:var(--warn)">■ High Value ≥₹2L | Aggregate ≥₹10L</span>
      <span style="color:var(--info)">■ Round Figure | Frequent Transactions</span>
      <span style="margin-left:auto">Sec 44AB / 269SS / 269T / SFT compliant</span>
    </div>

  <?php endif; ?>
</div>

<footer>P-ANALYSIS · CA Audit Tool · Income Tax &amp; GST · Sec 44AB / 269SS / 269T / SFT</footer>
<?php endif; ?>

<script>
function filterTable(){
  const q=document.getElementById('partySearch').value.toLowerCase();
  document.querySelectorAll('#auditTable tbody tr').forEach(r=>{
    r.style.display=r.cells[1].textContent.toLowerCase().includes(q)?'':'none';
  });
}
</script>
</body>
</html>